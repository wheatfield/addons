reFocus for Kodi (formerly known as XBMC Mediacenter)
============

reFocus is a graphical interface for Kodi that understands your media is what truly matters. Elegance, simplicity, refinement, consistency and balanced design are keywords for this skin.

### Download and installation
For instructions please see the wiki [here] (https://github.com/jeroenpardon/skin.refocus/wiki#installing-refocus)

### License
[Attribution-NonCommercial-ShareAlike 3.0 Unported](http://creativecommons.org/licenses/by-nc-sa/3.0/)

### Links
[FAQ](https://github.com/jeroenpardon/skin.refocus/wiki)

[reFocus forum](http://forum.kodi.tv/forumdisplay.php?fid=72)

[Kodi](http://www.kodi.tv/)
